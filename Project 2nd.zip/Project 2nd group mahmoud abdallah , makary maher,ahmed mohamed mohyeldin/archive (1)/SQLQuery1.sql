select * from [dbo].[OLE DB customer]
select customerID,MultipleLines from [Basic services]
select top 10 ([MultipleLines])from [dbo].[Basic services]